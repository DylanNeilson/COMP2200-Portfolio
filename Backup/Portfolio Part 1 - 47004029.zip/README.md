# Portfolio
Name: Dylan Neilson

Student ID: 47004029

This repository comprises the necessary files for the Portfolio task assigned in COMP2200/6200 S1 2023. 

The dataset required for part 1 of the porfolio task is located in the 'data' folder, which contains
the file (Yelp_Portfolio1_Input.csv). Downloaded from the following link:
 https://github.com/COMP2200-S1-2023/portfolio-part-1-dataset/releases/download/portfolio-dataset-p1/Yelp_Portfolio1_Input.csv
