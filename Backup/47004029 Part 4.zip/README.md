# Portfolio

Name: Dylan Neilson

Student ID: 47004029

This repository comprises the necessary files for the Portfolio Part 1, Part 2, Part 3 & Part 4 tasks assigned in COMP2200/6200 S1 2023.

The datasets required for both part 1, part 2, part 3 & part 4 of the porfolio tasks is located in the 'data' folder.

Yelp_Portfolio1_Input.csv - Downloaded from the following link: https://github.com/COMP2200-S1-2023/portfolio-part-1-dataset/releases/download/portfolio-dataset-p1/Yelp_Portfolio1_Input.csv
